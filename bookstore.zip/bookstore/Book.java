/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/* Name: James Rock
 Course: CNT 4714 – Fall 2019
Assignment title: Program 1 – Event-driven Programming     
Date: Sunday September 22, 2019
 */
   package BookStore;
   public class Book {
	
  private double price;
  private int bookID;
  private String title;
  
public double getPrice() 
{
	return price;
	}
public void setPrice(double price) 
	{
	this.price = price;
	}
public int getBookID() 
	{
	return bookID;
	}
public void setBookID(int bookID) 
	{
	this.bookID = bookID;
	}
public String getTitle() 
	{
	return title;
	}
public void setTitle(String title) 
	{
	this.title = title;
	}
}

