/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package BookStore;

/*Name: James Rock
 Course: CNT 4714 – Fall 2019
Assignment title: Program 1 – Event-driven Programming     
Date: Sunday September 22, 2019
 */

 import java.awt.*;
 import java.awt.event.*;
 import java.io.File;
 import java.io.FileNotFoundException;
 import java.io.IOException;
 import java.text.DecimalFormat;
 import javax.swing.*;
 import java.util.*;

public class BookStore extends JFrame  {
	
   private String inputfile = "inventory.txt";
   private String subtotalstring = "Order subtotal for ";
   private String askinguser1 ="Enter Book ID for Item #";
   private String askinguser2 ="Enter quantity for Item #";
   private ArrayList<Book> allbooks;
   private Order order = new Order();
	
//Text Field
private JTextField nitems = new JTextField();
private JTextField idofbook = new JTextField();
private JTextField quant = new JTextField();
private JTextField infoitems = new JTextField();
private JTextField itemstotal = new JTextField();

//Buttons
private JButton itemproccess = new JButton("Process Item #1");// need to update item 
private JButton itemconfirm = new JButton("Confirm Item #1");// need to update item #
private JButton vieworder = new JButton("View Order");
private JButton finishorder = new JButton("Finish Order");
private JButton neworder = new JButton("New Order");
private JButton exit1 = new JButton("Exit");

	// Jlabel
	JLabel subtotal1 = new JLabel("Order Subtotal for 0 item(s):");
	JLabel bookid = new JLabel("Enter Book ID for Item #1:");
	JLabel quantity1 = new JLabel("Enter Quantitiy for Item #1:");
	JLabel infoitems1 = new JLabel("Item #1 Info:");

public void getInventoryFromFile() throws FileNotFoundException {
		
// load all books in arraylist
	this.allbooks = new ArrayList<Book>();
	File file = new File("inventory.txt");
	Scanner textFile = new Scanner(file);

	// scan allbooks in arraylist
	while (textFile.hasNextLine())
      {
	
 // grab next books line and parse into 3 string
		String book = textFile.nextLine();
		String[] bookInfo = book.split(",");
		// create book and set fields
		Book currentBook = new Book();
		currentBook.setBookID(Integer.parseInt(bookInfo[0]));
		currentBook.setTitle(bookInfo[1]);
        currentBook.setPrice(Double.parseDouble(bookInfo[2]));
        
        
		// add to allbook array
		allbooks.add(currentBook); }
	
		textFile.close();
		
		for (int i = 0; i < allbooks.size(); i++) {
			Book current = allbooks.get(i);
			System.out.println(current.getBookID() + ", " + current.getTitle() + ", " + current.getPrice());
		} //test
		
	}

public BookStore() throws FileNotFoundException {
	this.getInventoryFromFile();
	JPanel panelgrid = new JPanel(new GridLayout(5,2));
	
	panelgrid.add(new JLabel("Enter number of items in this order:"));
	panelgrid.add(nitems);
	panelgrid.add(bookid);
	panelgrid.add(idofbook);
	panelgrid.add(quantity1);
	panelgrid.add(quant);
	panelgrid.add(infoitems1);
	panelgrid.add(infoitems);
	panelgrid.add(subtotal1);
	panelgrid.add(itemstotal); //panel holds six buttons
	
	JPanel panelgrid1 = new JPanel(new FlowLayout(FlowLayout.CENTER));
	panelgrid1.add(itemproccess);
	panelgrid1.add(itemconfirm);
	panelgrid1.add(vieworder);
	panelgrid1.add(finishorder);
	panelgrid1.add(neworder);
	panelgrid1.add(exit1);
		
	//deactivate button
	this.itemconfirm.setEnabled(false);
	this.vieworder.setEnabled(false);
	this.finishorder.setEnabled(false);
		
	// deactivate textfield
	this.itemstotal.setEnabled(false);
	this.infoitems.setEnabled(false);
		
	
	// add panels to frame
	add(panelgrid, BorderLayout.NORTH);
	add(panelgrid1, BorderLayout.SOUTH);
		
		
	// actionlisteners for all button
	itemproccess.addActionListener(new ActionListener() 
	
	{
 @Override
	public void actionPerformed(ActionEvent e) 
    {
			
		int numOfItemsInOrder = Integer.parseInt(nitems.getText());
		int bookID = Integer.parseInt(idofbook.getText());
		int quantityOfItem = Integer.parseInt(quant.getText());
                        
	//maxNumofItems new order
		if(order.getMaxNumItems() == -1 && numOfItemsInOrder > 0) {
		order.setMaxNumItems(numOfItemsInOrder);
		nitems.setEnabled(false);
}
		
		int bookIndex = linearSearch(bookID); // search book
		
		if(bookIndex != -1) {  //find book
			
		//item info order to print
				Book foundBook = allbooks.get(bookIndex);
				order.setItemInfo(foundBook.getBookID() + "", foundBook.getTitle(), foundBook.getPrice() + "", quantityOfItem + "", (order.totaldis(quantityOfItem)*0.01) + "", order.gettotaldis1(quantityOfItem, foundBook.getPrice()) + "");
				String bookInfo = foundBook.getBookID() + foundBook.getTitle() +  " $" + foundBook.getPrice() + " " + quantityOfItem + " " + (order.totaldis(quantityOfItem) + "% $" )+ order.gettotaldis1(quantityOfItem, foundBook.getPrice()); //need to get discound
				infoitems.setText(bookInfo);
				itemconfirm.setEnabled(true);
				itemproccess.setEnabled(false);
				order.setOrderSubtotal(quantityOfItem, foundBook.getPrice());
				infoitems.setEnabled(false);
				itemstotal.setEnabled(false); }
		
		//no book found display alert
		else {
		JOptionPane.showMessageDialog(null, "Book ID " +bookID + " not in file.");
			}
		}
	});
	itemconfirm.addActionListener(new ActionListener(){		
		@Override
		public void actionPerformed(ActionEvent e) {
		int numOfItemsInOrder = Integer.parseInt(nitems.getText());
		int bookID = Integer.parseInt(idofbook.getText());
		int quantityOfItem = Integer.parseInt(quant.getText());
				
		if(numOfItemsInOrder > order.getMaxNumItems())
			System.out.println("went over qantity");
				
		//increment currentNumofItems
		order.setCurrentNumItems(quantityOfItem);

		//update subtotal
		order.setTotalItems(order.getTotalItems() + 1);
				
		JOptionPane.showMessageDialog(null, "Item #" +order.getTotalItems() + " accepted");
				
			//prepare transaction.txt
			order.prepareTransaction();
				
			// viewOrder
			order.addToViewOrder(infoitems.getText());
				
			
		//enable buttons
		itemproccess.setEnabled(true);
		vieworder.setEnabled(true);
		finishorder.setEnabled(true);
		itemconfirm.setEnabled(false);
		nitems.setEnabled(false);
				
		//update button text
		itemproccess.setText("Process Item #" + (order.getTotalItems() + 1));
		itemconfirm.setText("Confirm Item #" + (order.getTotalItems() + 1));			
	//update textFields
	idofbook.setText("");
quant.setText("");
itemstotal.setText("$" +  new DecimalFormat("#0.00").format(order.getOrderSubtotal())); //update label
				
 subtotal1.setText(subtotalstring + numOfItemsInOrder + " item(s)");
bookid.setText(askinguser1 + (order.getTotalItems() + 1) + ":");
quantity1.setText(askinguser2 + (order.getTotalItems() + 1) + ":");
if(order.getCurrentNumItems() <= order.getMaxNumItems())
infoitems1.setText("Item #" + (order.getTotalItems() + 1) + " info:");			
if(order.getCurrentNumItems() > order.getMaxNumItems()) 
{
			bookid.setVisible(false);
			quantity1.setVisible(false);
                               itemproccess.setText("Process Item");
                              itemconfirm.setText("Confirm Item");
		itemproccess.setEnabled(false);
		itemconfirm.setEnabled(false);
		}
	 }
		});
		
	vieworder.addActionListener(new ActionListener() {

		@Override
public void actionPerformed(ActionEvent e) {
	 JOptionPane.showMessageDialog(null, order.getViewOrder());
			}
		});
		
		finishorder.addActionListener(new ActionListener() 
{

		@Override
public void actionPerformed(ActionEvent e) { //write to transactions.txt
	try {
			order.printTransactions();
			JOptionPane.showMessageDialog(null,order.getFinishOrder());
				
}
      catch (IOException e1) {
	e1.printStackTrace();
		}
	BookStore.super.dispose(); //dispose frame
	}
});
		
		
	neworder.addActionListener(new ActionListener() 
  {

	@Override
	public void actionPerformed(ActionEvent e)
 {
				
				
	BookStore.super.dispose(); //dispose frame
	try
 {
	BookStore.main(null);
} 
catch (FileNotFoundException e1) 
{	
 e1.printStackTrace();
	}
	}
});
				
exit1.addActionListener(new ActionListener() 
{
	@Override
public void actionPerformed(ActionEvent e) {
		BookStore.super.dispose(); //dispose frame
	}
});
}

public int linearSearch(int BookID) {
	for(int i = 0; i < this.allbooks.size(); i++) {
	Book currentBook = allbooks.get(i);
	if(currentBook.getBookID() == BookID)
	return i;
	}

	return -1;
	}
	
public ArrayList<Book> getInventory() {
	return allbooks;
	}
public void setInventory(ArrayList<Book> allbooks) {
	this.allbooks = allbooks;
	}
		
public static void main(String[] args) throws FileNotFoundException {
	BookStore frame = new BookStore();
	frame.pack(); //fit window
	frame.setTitle("Book Store");
	frame.setLocationRelativeTo(null); 
	frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
	frame.setVisible(true); //display
}
}