/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package BookStore;

/*Name: James Rock
 Course: CNT 4714 – Fall 2019
Assignment title: Program 1 – Event-driven Programming     
Date: Sunday September 22, 2019
 */

 import java.io.File;
 import java.io.FileNotFoundException;
 import java.io.FileWriter;
 import java.io.IOException;
 import java.io.PrintWriter;
 import java.math.BigDecimal;
 import java.text.DecimalFormat;
 import java.text.SimpleDateFormat;
 import java.util.ArrayList;
 import java.util.Calendar;
 import java.util.Date;

 public class Order {
	  
  private String filename = "transactions.txt";
  private String separator = "line.separator";
  private String end1 = "Thanks for shopping at the Ye Olde Book Shoppe!";
  private String header = "Item# /ID / Price / Qty / Disc %/ Subtotal";
  private String subtotalstring = "Order subtotal:   $" ;
  private String taxrate= "Tax rate:     6%";
    
 // items 
 private ArrayList<String> items = new ArrayList<>();
 private StringBuilder viewOrder = new StringBuilder();
 private StringBuilder finishOrder = new StringBuilder();
 private int currentNumItems = 0;
 private double orderSubtotal = 0;
 private double orderTotal = 0;
 private int totalItems = 0;
 private int maxNumItems = -1;
 
 File file = new File(filename);
 String[] itemInfo = new String[6];	
 BigDecimal num  = new BigDecimal("58.988");
	
 public int getCurrentNumItems() {return currentNumItems;}
 public void setOrderSubtotal(int quantity, double bookPrice) {this.orderSubtotal = this.orderSubtotal + this.gettotaldis1(quantity, bookPrice);}public void setCurrentNumItems(int currentNumItems) {
 this.currentNumItems = this.currentNumItems + currentNumItems;
 } 
 
 public double getOrderSubtotal() {return orderSubtotal;}public int getTotalItems() {return totalItems;}
 public void setOrderTotal() {this.orderTotal = this.orderSubtotal + (.06 * this.orderSubtotal);}
 public void setTotalItems(int totalItems) {this.totalItems = totalItems;
 }
 
 public int getMaxNumItems() {	
 return maxNumItems;
 }
 
 public void setMaxNumItems(int maxNumItems) {	this.maxNumItems = maxNumItems;}public double getOrderTotal() {return orderTotal;}
 public String getFinishOrder() 
 {
 
	return this.finishOrder.toString();
	}
	
	
public void setItemInfo(String bookID, String title, String price, String quantityOfItem, String discountPercentage, String totalDiscount) {
	itemInfo[0] = bookID;
	itemInfo[1] = title;
	itemInfo[2] = price;
	itemInfo[3] = quantityOfItem;
	itemInfo[4] = discountPercentage;
	itemInfo[5] = totalDiscount; } //set item info
	
public String getViewOrder() 
{

return this.viewOrder.toString(); }
	
public void addToViewOrder(String order) {
	viewOrder.append(this.getTotalItems() + ". " + order);
	viewOrder.append(System.getProperty(separator));
	}
	
	
public String[] getItemInfo() //get Item info
{
		
	
return itemInfo;
}

public double gettotaldis1(int quantity, double bookPrice) {
		
	if(quantity >= 1 && quantity <= 4 )
	return (quantity * bookPrice);
	
	if(quantity >= 5 && quantity <= 9)
	return (bookPrice-(bookPrice*.1))*quantity;
        
	if(quantity >= 10 && quantity <= 14)
    return (bookPrice-(bookPrice*.15))*	quantity;
       
		
	if(quantity >= 15)
    return (bookPrice-(bookPrice*.2))*quantity;	
                  
	return 0.0; }
	



public int totaldis(int quantity) {
	if(quantity >= 1 && quantity <= 4 )
	return 0; //zero discount
		
	if(quantity >= 5 && quantity <= 9)
	return 10;//ten discount
		
	if(quantity >= 10 && quantity <= 14)
	return 15; //fifteen discount
	
	if(quantity >= 15)
	return 20; //twenty discount
	return 0; }

	//view order
public String viewOrder() 
{
   return filename;
		}

//Prepare transactions
public void prepareTransaction() 
{
  String lineItem = new String();
  for(int i = 0; i< this.itemInfo.length; i++)
  {
		
	  lineItem += this.itemInfo[i] + ", ";  }
		
     items.add(lineItem); }
	


public void printTransactions() throws IOException 
 {
	
	Calendar calendar= Calendar.getInstance();
	Date date = calendar.getTime();
	SimpleDateFormat permutation = new SimpleDateFormat("ddMMyyyyHHmm");
	SimpleDateFormat time = new SimpleDateFormat("hh:mm:ss a z");
	SimpleDateFormat dateFormat = new SimpleDateFormat("MM/dd/yy");		
               
	// set finsihOrder dialog box
	this.setFinishOrder(dateFormat.format(date), time.format(date));
		
		
	if(file.exists() == false) 
	{   //create file doesnt exist
		file.createNewFile(); }
		
	
	//append if true file exists
	PrintWriter outputStream = new PrintWriter(new FileWriter(filename, true));
			
		
	
	//write file
	for(int i = 0; i< this.items.size(); i++)
	{
		outputStream.append(permutation.format(date) + ", ");
		String lineItem = this.items.get(i);
		outputStream.append(lineItem);
		outputStream.append(dateFormat.format(date) + ", ");
		outputStream.append(time.format(date));
		outputStream.println(); }	
		outputStream.flush();
		outputStream.close(); }
	
public void setFinishOrder(String date, String time) 
 {
	this.setOrderTotal();
	this.finishOrder.append("Date: " + date + " " + time);
	this.finishOrder.append(System.getProperty(separator));
	this.finishOrder.append(System.getProperty(separator));
	this.finishOrder.append("Number of line items: " + this.getTotalItems());
	this.finishOrder.append(System.getProperty(separator));
	this.finishOrder.append(System.getProperty(separator));
	
	this.finishOrder.append(header);
	this.finishOrder.append(System.getProperty(separator));
	this.finishOrder.append(System.getProperty(separator));
	this.finishOrder.append(this.getViewOrder());
	this.finishOrder.append(System.getProperty(separator));
	this.finishOrder.append(System.getProperty(separator));
	this.finishOrder.append("Order total:      $" + new DecimalFormat("#0.00").format(this.getOrderSubtotal()));
	this.finishOrder.append(System.getProperty(separator));
	this.finishOrder.append(System.getProperty(separator));
	this.finishOrder.append(taxrate);
	this.finishOrder.append(System.getProperty(separator));
	this.finishOrder.append(System.getProperty(separator));
    
	this.finishOrder.append("Tax amount: $"+new DecimalFormat("#0.00").format(this.getOrderSubtotal()*0.06));
    this.finishOrder.append(System.getProperty(separator));
	this.finishOrder.append(System.getProperty(separator));
		
	this.finishOrder.append(subtotalstring+ new DecimalFormat("#0.00").format(this.getOrderTotal()));
	this.finishOrder.append(System.getProperty(separator));
	this.finishOrder.append(System.getProperty(separator));
	this.finishOrder.append(end1);
    } 
   }